
/* eslint-disable no-console */
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fileUpload = require('express-fileupload');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const { processFromUrl, processFromZip } = require('./processor');

const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: '50mb' }));
app.use(fileUpload({ useTempFiles: true }));
app.use('/static', express.static(path.join(__dirname, '..', 'web')));

app.get('/', (_req, res) => {
  res.sendFile(path.join(__dirname, '..', 'web', 'index.html'));
});

app.post('/convert/url', async (req, res) => {
  try {
    const { url } = req.body;
    if (!url) return res.status(400).json({ error: 'Missing url' });
    const jobId = uuidv4();
    const outcome = await processFromUrl(url, jobId);
    res.json({ jobId, ...outcome });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
});

app.post('/convert/zip', async (req, res) => {
  try {
    if (!req.files || !req.files.sitezip) {
      return res.status(400).json({ error: 'Missing file: sitezip' });
    }
    const jobId = uuidv4();
    const outcome = await processFromZip(req.files.sitezip.tempFilePath, jobId);
    res.json({ jobId, ...outcome });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Lovable→Elementor MVP running at http://localhost:${PORT}`));
