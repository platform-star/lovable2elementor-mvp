
const fs = require('fs');

/**
 * Build a minimal Elementor Kit JSON using our internal mapping.
 * This structure matches Elementor's import format loosely for MVP purposes.
 */
async function writeKit(outPath, mapping, media) {
  const kit = {
    version: '0.1-mvp',
    site_settings: mapping.globals,
    pages: mapping.pages.map(toElementorPage),
    media
  };
  fs.writeFileSync(outPath, JSON.stringify(kit, null, 2));
}

function toElementorPage(p) {
  return {
    title: p.title,
    slug: p.slug,
    content: p.sections.map(sec => ({
      elType: 'section',
      elements: [
        {
          elType: 'column',
          elements: sec.columns[0].widgets.map(toElementorWidget)
        }
      ]
    }))
  };
}

function toElementorWidget(w) {
  if (w.type === 'heading') {
    return {
      elType: 'widget',
      widgetType: 'heading',
      settings: { 
        title: w.text,
        header_size: w.level || 'h2'
      }
    };
  }
  if (w.type === 'text') {
    return {
      elType: 'widget',
      widgetType: 'text-editor',
      settings: { editor: w.html }
    };
  }
  if (w.type === 'image') {
    return {
      elType: 'widget',
      widgetType: 'image',
      settings: { image: { url: w.src } }
    };
  }
  if (w.type === 'button') {
    return {
      elType: 'widget',
      widgetType: 'button',
      settings: { text: w.label, link: { url: w.url, is_external: false } }
    };
  }
  return {
    elType: 'widget',
    widgetType: 'spacer',
    settings: { space: 15 }
  };
}

module.exports = { writeKit };
