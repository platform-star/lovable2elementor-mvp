
const path = require('path');
const fs = require('fs');
const { chromium } = require('playwright');
const AdmZip = require('adm-zip');
const { URL } = require('url');
const slugify = require('slugify');
const { mapDomToElementor } = require('./mapping/mapper');
const { writeKit } = require('./utils/kit');

function ensureDir(p) { if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true }); }

async function renderUrl(url) {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  await page.goto(url, { waitUntil: 'networkidle' });
  const html = await page.content();
  // collect images
  const images = await page.evaluate(() => Array.from(document.images).map(img => img.src));
  await browser.close();
  return { html, images };
}

async function downloadAssets(imageUrls, destDir) {
  const axios = require('axios');
  const mime = require('mime-types');
  const out = [];
  for (const img of imageUrls) {
    try {
      const resp = await axios.get(img, { responseType: 'arraybuffer' });
      const ext = mime.extension(resp.headers['content-type']) || 'png';
      const fname = slugify(path.basename(new URL(img).pathname) || 'image', { lower: true }) || 'image';
      const outPath = path.join(destDir, `${fname}.${ext}`);
      fs.writeFileSync(outPath, resp.data);
      out.push({ src: img, file: `media/${path.basename(outPath)}` });
    } catch (e) {
      // ignore individual failures
    }
  }
  return out;
}

async function processFromUrl(url, jobId) {
  const base = path.join(__dirname, '..', 'export', jobId);
  const mediaDir = path.join(base, 'media');
  ensureDir(base); ensureDir(mediaDir);

  const { html, images } = await renderUrl(url);
  const mapping = await mapDomToElementor(html, url);
  const media = await downloadAssets(images, mediaDir);
  const kitPath = path.join(base, 'elementor-kit.json');
  await writeKit(kitPath, mapping, media);

  // zip media
  const zip = new AdmZip();
  zip.addLocalFolder(mediaDir, 'media');
  const mediaZipPath = path.join(base, 'media.zip');
  zip.writeZip(mediaZipPath);

  // save report
  fs.writeFileSync(path.join(base, 'report.json'), JSON.stringify({ url, mapping, media }, null, 2));

  return { 
    kit: `export/${jobId}/elementor-kit.json`,
    media: `export/${jobId}/media.zip`,
    report: `export/${jobId}/report.json`
  };
}

async function processFromZip(tempPath, jobId) {
  const base = path.join(__dirname, '..', 'export', jobId);
  const unzipDir = path.join(base, 'unzipped');
  ensureDir(base); ensureDir(unzipDir);

  const zip = new AdmZip(tempPath);
  zip.extractAllTo(unzipDir, true);
  // naive: find index.html (or first html) and treat its path as entry
  const htmlFile = findFirstHtml(unzipDir);
  const html = fs.readFileSync(htmlFile, 'utf8');
  const mapping = await mapDomToElementor(html, `file://${htmlFile}`);

  // collect assets
  const mediaDir = path.join(base, 'media');
  ensureDir(mediaDir);
  const mediaFiles = collectImages(unzipDir);
  const rels = [];
  for (const f of mediaFiles) {
    const dest = path.join(mediaDir, path.basename(f));
    fs.copyFileSync(f, dest);
    rels.push({ src: f, file: `media/${path.basename(f)}` });
  }

  const kitPath = path.join(base, 'elementor-kit.json');
  await writeKit(kitPath, mapping, rels);

  const mediaZipPath = path.join(base, 'media.zip');
  const mzip = new AdmZip();
  mzip.addLocalFolder(mediaDir, 'media');
  mzip.writeZip(mediaZipPath);

  fs.writeFileSync(path.join(base, 'report.json'), JSON.stringify({ source: 'zip', mapping, media: rels }, null, 2));
  return { 
    kit: `export/${jobId}/elementor-kit.json`,
    media: `export/${jobId}/media.zip`,
    report: `export/${jobId}/report.json`
  };
}

function collectImages(rootDir) {
  const out = [];
  function walk(d) {
    for (const f of fs.readdirSync(d)) {
      const p = path.join(d, f);
      const s = fs.statSync(p);
      if (s.isDirectory()) walk(p);
      else if (/\.(png|jpe?g|gif|webp|svg)$/i.test(f)) out.push(p);
    }
  }
  walk(rootDir);
  return out;
}

function findFirstHtml(rootDir) {
  let found = null;
  function walk(d) {
    for (const f of fs.readdirSync(d)) {
      const p = path.join(d, f);
      const s = fs.statSync(p);
      if (s.isDirectory()) walk(p);
      else if (/\.(html|htm)$/i.test(f)) { found = found || p; }
    }
  }
  walk(rootDir);
  if (!found) throw new Error('No HTML file found in ZIP');
  return found;
}

module.exports = { processFromUrl, processFromZip };
