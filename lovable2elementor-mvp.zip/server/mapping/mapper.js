
const { JSDOM } = require('jsdom');

/**
 * Returns a simplified mapping: list of pages with sections and widgets.
 * MVP: we treat the provided HTML as a single 'Home' page.
 */
async function mapDomToElementor(html, sourceUrl) {
  const dom = new JSDOM(html);
  const doc = dom.window.document;

  const body = doc.body;
  const sections = [];
  // naive split by <section> (fallback: large direct children of body)
  const sectionNodes = body.querySelectorAll('section');
  const nodes = sectionNodes.length ? sectionNodes : body.children;

  for (const sec of nodes) {
    const secObj = { columns: [ { widgets: [] } ] };
    const widgets = secObj.columns[0].widgets;

    // headings
    sec.querySelectorAll('h1,h2,h3').forEach(h => {
      widgets.push({ type: 'heading', level: h.tagName.toLowerCase(), text: h.textContent.trim() });
    });

    // paragraphs
    sec.querySelectorAll('p').forEach(p => {
      const text = p.textContent.trim();
      if (text) widgets.push({ type: 'text', html: `<p>${escapeHtml(text)}</p>` });
    });

    // images
    sec.querySelectorAll('img').forEach(img => {
      widgets.push({ type: 'image', src: img.getAttribute('src') || '' });
    });

    // links/buttons
    sec.querySelectorAll('a,button').forEach(el => {
      const label = (el.textContent || '').trim() || 'Button';
      const href = el.getAttribute('href') || '#';
      widgets.push({ type: 'button', label, url: href });
    });

    if (widgets.length) sections.push(secObj);
  }

  const page = {
    title: 'Home',
    slug: 'home',
    sections
  };

  return { sourceUrl, pages: [page], globals: defaultGlobals() };
}

function defaultGlobals() {
  return {
    colors: [
      { id: 'primary', value: '#111827' },
      { id: 'secondary', value: '#6B7280' },
      { id: 'accent', value: '#2563EB' }
    ],
    typography: {
      body: { family: 'System', size: 16 },
      h1: { family: 'System', size: 40 },
      h2: { family: 'System', size: 32 }
    }
  };
}

function escapeHtml(str) {
  return str
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;');
}

module.exports = { mapDomToElementor };
